#!/usr/bin/env bash
# 先回归（option bytes + 全片擦除），再下载三份镜像
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"${SCRIPT_DIR}/regression.sh" "$@"
"${SCRIPT_DIR}/download.sh" "$@"
echo "全部完成。复位板子，串口 115200 8N1 看启动/测试日志。"
