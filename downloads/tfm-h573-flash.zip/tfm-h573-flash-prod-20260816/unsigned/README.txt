这里是未签名固件。包里已带当前编译出的 tfm_s.bin / tfm_ns.bin。

替换成你自己编的 bin 后，在上一级执行 ./sign.sh，会签好并覆盖 images/。

  tfm_ns.bin / *ns*.bin          →  images/tfm_ns_signed.bin
  tfm_s.bin  / *sapp* / *_s.bin  →  images/tfm_s_signed.bin

BL2（images/bl2.bin）不用签。
