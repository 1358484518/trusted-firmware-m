把编译出来的未签名 bin 放在这里，然后在上一级执行 ./sign.sh

  tfm_ns.bin / *ns*.bin     →  签成 images/tfm_ns_signed.bin
  tfm_s.bin  / *sapp* / *_s.bin  →  签成 images/tfm_s_signed.bin

BL2（images/bl2.bin）不用签，不要放在这里替换。
