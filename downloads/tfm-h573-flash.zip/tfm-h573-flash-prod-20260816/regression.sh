#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_find_cli.sh"
CLI="$(find_stm32_cli)"
sn_option=""
[[ $# -eq 1 ]] && sn_option="sn=$1"
connect="-c port=SWD ap=1 ${sn_option} mode=UR"
connect_hp="-c port=SWD ap=1 ${sn_option} mode=HotPlug"
echo "=== H573 回归（写 option bytes，会全片擦除）==="
"${CLI}" ${connect} -ob PRODUCT_STATE=0xED TZEN=0xB4
"${CLI}" ${connect} -ob SECWM1_STRT=127 SECWM1_END=0 WRPSGn1=0xffffffff -e all
"${CLI}" ${connect} -ob SECWM2_STRT=127 SECWM2_END=0 WRPSGn2=0xffffffff -e all
"${CLI}" ${connect_hp} -ob HDP1_END=0 HDP2_END=0
"${CLI}" ${connect_hp} -ob SECBOOTADD=0xC0100 HDP1_STRT=1 HDP1_END=0 HDP2_STRT=1 HDP2_END=0 SWAP_BANK=0 SRAM2_RST=0 SRAM2_ECC=0
"${CLI}" ${connect_hp} -ob SECWM2_STRT=0 SECWM2_END=127 SECWM1_STRT=0 SECWM1_END=127
echo "regression Done"
